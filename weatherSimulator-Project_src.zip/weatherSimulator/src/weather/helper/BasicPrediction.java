package weather.helper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;

import weather.domain.Weatherobject;

public interface BasicPrediction {

	public  ArrayList<Weatherobject> getTemprature (Collection<String> collection, String dates) throws ParseException;
	
}
