package weather.helper;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Random;

import weather.domain.Weatherobject;
import weather.utility.LocationUtil;

/*
 * @Author - karthik Nirav
 * 
 * Predictor Helper class takes in the Basic Prediction interface as the template.
 */
public class PredictionHelper implements BasicPrediction {

	 String TypeBseasons[] = {"Winter", "Winter","Spring", "Spring", "Spring", "Summer", "Summer", "Summer", "Fall", "Fall", "Fall","Winter"};
	 String TypeCseasons[] = {"Summer", "Summer","Fall", "Fall", "Fall", "Winter", "Winter", "Winter", "Spring", "Spring", "Spring","Summer"};

	// main function that takes care of the business logic and sets the response object  
	public  ArrayList<Weatherobject> getTemprature (Collection<String> collection, String dates) throws ParseException{
		
		ArrayList<Weatherobject> returnresult = new ArrayList<Weatherobject>();
		DecimalFormat df = new DecimalFormat("#.#");

		for(String coordinate : collection){
			Weatherobject wo = new Weatherobject();
			
			String plots [] = coordinate.split(",");
			String zone = getZone(plots[0]);
			
			// Convert the date to their Latitude time zone			
			dates = (getLocalizedDate(dates,plots[3],plots[1],plots[4]));			
			int month = Integer.parseInt(dates.substring(8, 10));
			int time = Integer.parseInt(dates.substring(11, 13));
			String TempandCondition = getSeasonAvgClimate(zone,month,time);
			String [] temp = TempandCondition.split("-");

			// Set the final output to the response object
			wo.setLatitude(Double.valueOf(df.format(Double.parseDouble(plots[0]))));
			wo.setLocation(plots[3]);
			wo.setPosition(plots[0]+","+plots[1]+","+plots[2]);
			wo.setLocalTime(dates);
			wo.setCondition(temp[1].toString());
			wo.setTemprature(df.format(altitudeVariance(plots[2],temp[0])));
			wo.setPreassure(Double.valueOf(df.format(getPreassure(Double.parseDouble(plots[2]),Double.parseDouble(temp[0])))));
			wo.setHumidity((int)getHumidity(Double.parseDouble(temp[0])));

			returnresult.add(wo);
		}
			
			return returnresult;
	}
	
	// making India as median standard point and navigating through east and west adding/subtracting hours respectively 
	public String getLocalizedDate(String date, String Location, String Lat, String offset) throws ParseException{

			double IndiaLong = 80.16;
			double latC =  Double.parseDouble(Lat) - IndiaLong;
	    	DateFormat parse = new SimpleDateFormat( "yyyy-MM-dd hh:mm:ss");
	    	DateFormat outFormat = new SimpleDateFormat( "yyyy-MM-dd hh:mm:ss");

			Date newDate = parse.parse(date);
			if (offset.equals("+")){
				Date newDate1 = new Date(newDate.getTime()+((int) Math.round(Math.ceil(latC/15))*60*60*1000));
				date = outFormat.format(newDate1);
			}else{
				Date newDate1 = new Date(newDate.getTime()-((int) Math.round(Math.ceil(latC/15))*60*60*1000));
				date = outFormat.format(newDate1);
			}
		
			return date;
	}
	
	// Humidity is calculated based on the Dewpoint variance
	public double getHumidity(double t){
		
		t = Math.ceil(t);
			if (t > 36 && t < 38){
				return 100;
			}else if (t >37.0 && t < 46.0){
				return 80;
			}else if(t > 45.0 && t < 50.0){
				return 65;
			}else if (t > 49.0 && t < 51.0){
				return 50;			
			}else if (t > 50.0 && t < 61.0){
				return 40;				
			}else if (t > 60.0 && t < 71.0){
				return 30;
			}else if (t > 70.0 && t < 81.0){
				return 20;
				}
				else {
					return randomFunc(-10,5);
			}
	}
	
	// Kesian pressure formula. Pressure based on Altitude and Temprature
	public double getPreassure (double h,double t){
				
		double base = (1-(.0065*h/(t+(.0065*h)+273.15)));
		double pow = Math.pow(base, 5.257);
		return 1013.25*pow;
	}

	// For every 1000 m 3.5 C is decreased
	public double altitudeVariance (String plots, String temp){
		
		double date = Double.parseDouble(temp) - (( Double.parseDouble(plots)/1000)*3.5) ;
		
		// convert F to C
		
		date = (date-32)*.5556;
		
		return date;
	}
	
	public boolean isRain(String Season){
		if (Season.equals("Summer")){	
			if (randomFunc(1,10) > 8) return Boolean.TRUE; 
		}
		if (Season.equals("Winter")){
			if (randomFunc(1,10) > 7) return Boolean.TRUE;
		}
		if (Season.equals("Spring")){
			if (randomFunc(1,10) > 7) return Boolean.TRUE;
		}
		if (Season.equals("Fall")){
			if (randomFunc(1,10) > 6) return Boolean.TRUE;
		}
		
		return Boolean.FALSE;
	}
	
	public boolean isSnow(String Season){

		if (Season.equals("Winter")){
			if (randomFunc(1,10) > 5) return Boolean.TRUE;
		}		
		return Boolean.FALSE;
	}
	
	public double randomFunc (int min, int max){
		Random r = new Random();
		return min + (max - min) * r.nextDouble();
	}
	
	// Temprature is calculated baesd on the Zone they are and the Seasons they come under. Based on that temprature is calculated.
	public String getSeasonAvgClimate(String zone, int month, int time){
		String hold;
        String Season;
		double temp = 0;
		String Condition = "Sunny";
		
		 hold = (LocationUtil.weatherZone.get(zone));
		 String holds [] = hold.split(",");

		 
		 /* Check for the Type of the Zone the latitude falls
		  * Check the seAson for the zone
		  * Check possibility of Snow in winter
		  * Possibility of rain throughout the year
		  */
		 
		//============== Equator Begin ====================//
		 
		if (zone.equals("TypeA")){
			
			// Summer for Equator
			if (month > 3 && month < 9){
					temp = Double.parseDouble(holds[1]);
					if(isRain("Summer")){
						temp = temp - randomFunc(15,20);
						Condition = "Rain";
					}else
						{ // go for normal weather for the season
							if (time > 9 && time < 16){
								temp += randomFunc(1, 6);
							}
							else { temp = Double.parseDouble(holds[2]) + randomFunc(1,4); 
							}
							Condition = "Sunny";
						}
			}// Mild-Summer for Equator
			else{
				temp = Double.parseDouble(holds[3]);
				if(isRain("Fall")){					
					temp = temp - randomFunc(15,20);
					Condition = "Rain";
				}else
					{ // go for normal weather for the season
						if (time > 9 && time < 16){
							temp += randomFunc(1, 5);
						}
						else { temp = Double.parseDouble(holds[4]) + randomFunc(1,4); }
						Condition = "Sunny";
					}
			}
			
		}
		//============== Equator End ====================//
		
		if (zone.equals("TypeB") || zone.equals("TypeC")){
			
			if(zone.equals("TypeB"))
				Season  = (TypeBseasons[month-1]);
			else Season  = (TypeCseasons[month-1]);
			 
			 // Snow Possibility 
			 if (Season.equals("Winter")){
				 if (isSnow(Season)){
					 temp = Double.parseDouble(holds[4]) - randomFunc(10, 20);
					 Condition = "Snow";
					 return temp+"-"+Condition;
				 } else{
						if (time > 9 && time < 16){
							temp = Double.parseDouble(holds[3]) + randomFunc(6,10);						
						}else { 
							temp = Double.parseDouble(holds[4]) + randomFunc(3,5); 
						}					 
				 } 
			 } 
			 // Rain Possibility - Any time in Tropic region will get rain
				 if (isRain(Season)){
					 temp = Double.parseDouble(holds[4]) - randomFunc(1, 3);
					 Condition = "Rain";
					 return temp+"-"+Condition;
				 }
			 
				 // Summer Period
			 if (Season.equalsIgnoreCase("Summer")){
					if (time > 9 && time < 16){
						temp = Double.parseDouble(holds[1]) + randomFunc(-6,4);						
					}else { 
						temp = Double.parseDouble(holds[2]) + randomFunc(-6,2); 
					}
					
					return temp+"-"+"Sunny";
			 }
			 
			 // Spring Period

			 if (Season.equalsIgnoreCase("Spring")){
					if (time > 9 && time < 16){
						temp = Double.parseDouble(holds[1]) + randomFunc(1,4) - randomFunc(5, 8);						
					}else { 
						temp = Double.parseDouble(holds[2]) + randomFunc(1,2) - randomFunc(2, 3); 
					}
					return temp+"-"+"Sunny";
			 }

			 // Fall Period
	 
			 if (Season.equalsIgnoreCase("Fall")){
					if (time > 9 && time < 16){
						temp = Double.parseDouble(holds[1]) + randomFunc(1,4);						
					}else { 
						temp = Double.parseDouble(holds[2]) + randomFunc(-2,2); 
					}
					return temp+"-"+"Sunny";
			 }
			 
		}
		//============== Tropic of Cancer End ====================//		
		//============== Tropic of Capricon End ====================//
		
		return temp+"-"+Condition;
	}

	// The world is split into several zones, using the zones to identify the climate of the regions
	public String getZone(String zone){
			
		double numeric = Math.signum(Double.parseDouble(zone));
		double value = Double.parseDouble(zone);
		
		
		if(numeric > 0){
			
			if (value > 23.5 && value < 66.5 )
			{
				return "TypeB";
			}
			else if ( value > 66.5 ){
				return "TypeD";
			}
			else {
				return "TypeA";
			}
		}
		else{
			value = value * -1;
			if (value > 23.5 && value < 66.5 )
			{
				return "TypeC";
			}
			else if ( value > 66.5 ){
				return "TypeE";
			}
			else {
				return "TypeA";
			}
			
		}
	}
}
