package weather.domain;
/**
 * @author karthik-nirav
 * WeatherObject bean is the place holder for the request/response object to/from the user
 */

public class Weatherobject implements Comparable<Object> {

	private String Location;
	private double Latitude;
	private String Position;
	private String LocalTime;
	private String Condition;
	private String Temprature;
	private Double Preassure;
	private int	Humidity;

	public double getLatitude() {
		return this.Latitude;
	}

	public void setLatitude(Double latitude) {
		this.Latitude = latitude;
	}
	
	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getPosition() {
		return Position;
	}

	public void setPosition(String position) {
		Position = position;
	}

	public String getLocalTime() {
		return LocalTime;
	}

	public void setLocalTime(String localTime) {
		LocalTime = localTime;
	}

	public String getCondition() {
		return Condition;
	}

	public void setCondition(String condition) {
		Condition = condition;
	}

	public String getTemprature() {
		return Temprature;
	}

	public void setTemprature(String temprature) {
		Temprature = temprature;
	}

	public Weatherobject() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Double getPreassure() {
		return Preassure;
	}

	public void setPreassure(Double preassure) {
		Preassure = preassure;
	}

	public int getHumidity() {
		return Humidity;
	}

	public void setHumidity(int humidity) {
		Humidity = humidity;
	}

	@Override
	public String toString() {
		return  getLocation() + "|" + getPosition()+ "|" + getLocalTime() + "|" + getCondition() + "|"+ getTemprature() + "|" + getPreassure() + "|" + getHumidity();
	}
	
	/**
	 * Overide the default comparator to sort by Latitude 
	 */
	@Override
	public int compareTo(Object compareLat) {
		 double compare=((Weatherobject)compareLat).getLatitude();
	        return (int) (this.Latitude-compare);	}
    
}
