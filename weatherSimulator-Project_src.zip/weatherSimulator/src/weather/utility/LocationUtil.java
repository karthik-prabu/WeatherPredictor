package weather.utility;

/**
 * @author karthik-nirav
 * Utility class that provides the 20 Geo points basic parameters for the processing. 
 */
import java.util.HashMap;
	
public class LocationUtil {

	/*
	 * Input : Location, Latitude and Longitude, Elevation 
	 * ELEVATION : It is obtained from the AltitudeUtil.java class 
	 * the class uses Google Elevation API to provide elevation for the given coordinates 
	 * saved the result of API Values in MAP
	 */
	public static HashMap<String,String> weatherMapCoordinates =
			new HashMap<String, String>();
	
	/**
	 * Sets the weather zone for the provided coordinates
	 */
	public  static final HashMap<String,String> weatherZone =
			new HashMap<String, String>();
	
	static {
				weatherMapCoordinates.put("Hobart","-42.52,147.19,118,Hob,+");
				weatherMapCoordinates.put("Melbourne","-37.83,144.98,5,Mel,+");
				weatherMapCoordinates.put("Adelaide","-34.92,138.62,43,Adl,+");
				weatherMapCoordinates.put("Sydney","-33.86,151.21,3.5,Syd,+");
				weatherMapCoordinates.put("Perth","-31.57,115.51,-29,Per,+");
				weatherMapCoordinates.put("Brisbane","-27.28,153.02,7,Bri,+");
				weatherMapCoordinates.put("George Town","5.25,100.19,14,GT,+");
				weatherMapCoordinates.put("Colombo","6.56,79.50,1,Col,+");
				weatherMapCoordinates.put("Chennai","13.50,80.16,0,Chn,+");
				weatherMapCoordinates.put("Puerto Rico","18.20,66.50,1339,PR,-");
				weatherMapCoordinates.put("Hawaii","21.18,157.47,4205,HI,-");
				weatherMapCoordinates.put("Florida","28.10,81.60,149,FL,-");
				weatherMapCoordinates.put("Delhi",	"28.36,77.13,292,Del,-");
				weatherMapCoordinates.put("Arizona","34.00,112.00,708,Arz,-");
				weatherMapCoordinates.put("Los Angeles","34.03,118.15,17,LA,-");
				weatherMapCoordinates.put("New York","43.00,75.00,814,NY,-");
				weatherMapCoordinates.put("Paris","48.51,2.21,92,Par,-");
				weatherMapCoordinates.put("Berlin","52.31,13.23,55,Ber,-");

				weatherZone.put("TypeA","Equator,96,80,87,76");		
				weatherZone.put("TypeC","Tropic Of Capricon,88,70,65,60");
				weatherZone.put("TypeB","Tropic Of Cancer,85,70,62,60");
				weatherZone.put("TypeD","Arctic");
				weatherZone.put("TypeE", "Antarctic");

		}
	}
