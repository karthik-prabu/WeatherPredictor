package weather.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 
 * @author karthik-Nirav
 * DateUtil was initially created to handle all date formats/operations but, currently helps to validate the date inputs. 
 */
public class DateUtil{
	public static void validDate(String str) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");		  
	            sdf.setLenient(false);
				sdf.parse(str);
	}
}