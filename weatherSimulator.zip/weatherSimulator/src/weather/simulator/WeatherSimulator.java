package weather.simulator;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;

import weather.domain.Weatherobject;
import weather.utility.DateUtil;

/**
 * 
 * @author karthik-Nirav
 * Main class that invokes the requestALL as well as specific Location details
 */
public class WeatherSimulator {

	public static void main (String args[]){
		
		System.out.println("Usage : \n"
				+ " Option 1: Enter the <year> eg : 2011-12-12 12:00:00 \n"
				+ " Option 2: Enter the <Location, date-year > eg : Perth 2015-12-12 16:00:45 (24 Hour Format) \n" 
				+ " Locations Supported \n"
				+ " Hobart,Melbourne,Adelaide,Sydney,Perth,Brisbane,George Town,Colombo,Chennai,Puerto Rico,Hawaii,Florida,Delhi,Arizona,Los Angeles,New York,Paris,Berlin \n");
		System.out.println();
		try {
		
		ArrayList<Weatherobject> predictplots = null;
		
		int Option = args.length;
		
		
		if(Option==1){
		// Option 1 :
			DateUtil.validDate(args[0]);
			predictplots = new WeatherPredictor().getAllPredictors (args[0]);
		}else if(Option==2){
		// Option :2
			DateUtil.validDate(args[1]);
			predictplots = new WeatherPredictor().getPredictors (args[0],args[1]);
		}else{
			System.out.println("Invalid Arguments ");
			System.exit(0);
		}
		//Sort based on the Latitude order
		if(predictplots != null){
			Collections.sort(predictplots);
		
			for(Weatherobject predictplot : predictplots)
				System.out.println(predictplot);
			}
		else{
			System.out.println("Invalid Location");
		}
		} catch (ParseException e) {
			System.out.println("Invalid Parameters, Please check the Usage");
		}
	}	
}