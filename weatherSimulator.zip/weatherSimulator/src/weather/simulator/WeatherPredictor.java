package weather.simulator;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;

import weather.domain.Weatherobject;
import weather.helper.BasicPrediction;
import weather.helper.PredictionHelper;
import weather.utility.LocationUtil;

/**
 * 
 * @author karthik-Nirav
 * Option to get the All the location details or specific location details
 *
 */
public class WeatherPredictor{

	BasicPrediction prediction = new PredictionHelper();
		
	public  ArrayList<Weatherobject> getAllPredictors (String dates) throws ParseException{
		
		ArrayList<Weatherobject> returnresult = new ArrayList<Weatherobject>();
		HashMap <String, String> Allcoordinates = LocationUtil.weatherMapCoordinates;			
		Collection<String> coordinates = Allcoordinates.values();
		returnresult = prediction.getTemprature( coordinates,dates);		
		return returnresult;
	}
	


	public  ArrayList<Weatherobject> getPredictors (String Location, String dates) throws ParseException{
		ArrayList<Weatherobject> returnresult = new ArrayList<Weatherobject>();
		String coordinates = LocationUtil.weatherMapCoordinates.get(Location);
		if (coordinates != null){
			Collection<String> convert = Arrays.asList(coordinates);
			returnresult = prediction.getTemprature(convert,dates);
		}
		return returnresult;
	}
	
	
 }
