package weather.utility;

import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

import org.json.*;

/**
 * 
 * @author karthik-Nirav
 * Gets the Elevation from the Google API, Saved the result in the MAP to avoid repeated Webservice calls
 */
public class AltitudeUtil {

    public static void main(String[] args) throws IOException, JSONException {
    	
		HashMap <String, String> Allcoordinates = LocationUtil.weatherMapCoordinates;			
		Collection<String> coordinates = Allcoordinates.values();

    	String s = "https://maps.googleapis.com/maps/api/elevation/json?key=AIzaSyBuvFOEQsZwTV71slE8YAYw7Xjvy-DWavc&";
    	
    	for(String cols : coordinates){
    		
    	String [] arg = cols.split(",");
    	
    	URL url = new URL(s+"locations="+arg[0]+","+arg[1]);

    	Scanner scan = new Scanner(url.openStream());
    	StringBuilder sbr = new StringBuilder();
    	while (scan.hasNext())
    			sbr.append(scan.nextLine());
    			
    	scan.close();

    	JSONObject obj = new JSONObject(sbr.toString());
    	JSONObject res = obj.getJSONArray("results").getJSONObject(0);
    	System.out.println(res.getString("elevation"));
    	}
    	}
	}